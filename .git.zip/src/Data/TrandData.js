export const TrandData = [

    {
        name: "Minions",
        shares: 97,
    },

    {
        name: "Avangers",
        shares: 80.5,
    },

    {
        name: "Zainkeepscode",
        shares: 75.5,
    },


    {
        name: "Reactjs",
        shares: 72,
    },

    {
        name: "Minions",
        shares: 97,
    },

    {
        name: "Need for Speed",
        shares: 20,
    },


];