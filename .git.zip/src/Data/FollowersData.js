import img1 from "../img/img1.png";
import img2 from "../img/img2.png";
import img3 from "../img/img3.png";
import img4 from "../img/img4.jpg";

export const Followers = [
    {name: "Andrew Thomas", username: "AndrewThomas", img: img1},
    {name: "Charli Thomas", username: "charliThomas", img: img2},
    {name: "Thor", username: "ThorBirli", img: img3},
    {name: "Anjalica ", username: "Anjalica Thomas", img: img4},
];