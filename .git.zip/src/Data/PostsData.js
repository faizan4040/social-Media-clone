import PostPic1 from '../img/PostPic1.jpg'
import PostPic2 from '../img/PostPic2.jpg'
import PostPic3 from '../img/PostPic3.jpg'


export const PostData = [

{
    img: PostPic1,
    name: 'Tzuyu',
    desc: "Happy Diwali all My Friends",
    likes: 1400,
    Liked: true, 
    
},

{
    img: PostPic2,
    name: 'Maryam',
    desc: "Happy Diwali all My Friends",
    likes: 1400,
    Liked: false, 
    
},


{
    img: PostPic3,
    name: 'Thomas',
    desc: "Happy Diwali all My Friends",
    likes: 1400,
    Liked: false, 
    
},


];